local _M = {}

user = Items\create {
    Name: "Adam"
}

local 
function _M.show_table()
    return Items\find 1
end

return _M
