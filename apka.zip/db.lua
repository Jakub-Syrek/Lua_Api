local config = require("lapis.config").get()
return require("lapis.db.mysql")
