local lapis = require "lapis"

local Model = require("lapis.db.model").Model

local Aplication = require("lapis.application")
local Errors = Aplication.capture_errors

local Preload = require("lapis.db.model").preload
local Validate = require("lapis.validate")

local app = lapis.Application()

app:get('/', function(self))
    help = {}
    help[1] = "info"
    return table.concat(help,"<br><br>")

end)

return app