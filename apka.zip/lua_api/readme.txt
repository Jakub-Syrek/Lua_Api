    
    --curl -X POST http://localhost:8080/create/?id=14&name=IPShares7&bid=33&ask=34&typeid=3
    ---H 'Content-Type: application/json' -d '{"id":14,"name":"IPShares7","bid":33,"ask":34,"typeid":3}'

--?myparam1={id1}&myparam2={id2} 